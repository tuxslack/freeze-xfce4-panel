🇧🇷 Português (PT-BR):

    Utilitário para congelar e descongelar o painel do Xfce em distribuições baseadas no Debian.

    Por favor, envie comentários, sugestões ou relatos de bugs para: Claudio A. Silva — claudiosilva@duzeru.org

    Verifique novas versões em: https://github.com/tuxslack/freeze-xfce4-panel

🇬🇧 English (EN):

    Utility to freeze and unfreeze the Xfce panel on Debian-based distributions.

    Please report comments, suggestions, or bugs to: Claudio A. Silva — claudiosilva@duzeru.org

    Check for new versions at: https://github.com/tuxslack/freeze-xfce4-panel

